<?php
session_start();
$logo = '<svg xmlns="http://www.w3.org/2000/svg" width="30" height="18" fill="currentColor" class="bi bi-person-circle" viewBox="0 0 16 16">
<path d="M11 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0z"/>
<path fill-rule="evenodd" d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8zm8-7a7 7 0 0 0-5.468 11.37C3.242 11.226 4.805 10 8 10s4.757 1.225 5.468 2.37A7 7 0 0 0 8 1z"/>
</svg>'

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Argentinian</title>
    <link rel="shortcut icon" href="img/pag1/icono.jpg">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Staatliches&family=Work+Sans:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/normalize.css">
    <link rel="stylesheet" href="css/style.css">


</head>
<body>
    <!--NAV-->
    <nav class="pag__nav">
        <div class="pag__nav__div__img"> <a class="pag__nav__imgLink" href="index.php"><img class="pag__nav__img" src="img/pag1/logo.png"></a></div>
        <div class="pag__nav__div__a">
            <a href="enindex.php" class="pag__nav__a">Home</a>
            <a href="enhistoria.php" class="pag__nav__a">History</a>
            <a href="encampeonatos.php" class="pag__nav__a">Tournament</a>
            <a href="enuruguayo.php" class="pag__nav__a">Uruguayan</a>
            <a href="../es/argentino.php" class="pag1__a">ES</a>

            <?php

                if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true) {

                    echo '<a href="./Login/user.php" class="pag__nav__a">' . $_SESSION["username"] . $logo .'</a>';

                }else{
                    echo '<a href="./Login/user.php" class="pag__nav__a">Cuenta</a>';
                }
            ?>
        </div>
    </nav>

    <header class="pag4__header">
        <!--carrusel-->

    </header>

    <main class="pag4__main">

        <!-- SECTION A   = Reglas de juego-->
        <section class="pag4__sectionA">
            <div class="pag4__sectionA__divH2">
                <h2 class="pag4__sectionA__h2">Rules of the Game</h2>
            </div>
            <div class="pag4__sectionA__divP">
                <p class="pag4__sectionA__p">
                Truco Argentinian is a card game traditionally played in Argentina and some other regions of Latin America. Next, I provide you with a basic regulation to play Truco Argentina: <br> <br>

<span> Deck: </span> <br>
  A Spanish deck of 40 cards is used. This deck excludes 8s and 9s from all suits. <br>

<br> <span>Number of players: </span> <br>
  Truco Argentinian is typically played with four players, organized into two teams of two people each. The players of each team sit opposite each other. <br>
  <br>
  Card distribution: <br>
  Cards are dealt counterclockwise, starting with the player to the right of the dealer. Each player is dealt three cards in the first round and then four cards are dealt in subsequent rounds. The dealer changes each round. <br>
  <br>
  Game development: <br>
  The game is played in rounds, and the goal is to win the most rounds. Each round consists of two parts: the "going" and the "return". <br>

 <br> The first leg: In the first leg, players place a card in the center of the table, and the team that plays the highest card wins the first leg. If both teams play cards of the same value, the first leg is tied and no points are awarded. <br>

 <br> The round: In the round, the players place another card in the center of the table, and the team that wins the round takes the corresponding points. The value of the cards in the return is different from the value in the first leg. The cards have the following values in the round, from highest to lowest: 3, 2, 1 of Swords, Cups and Gold, respectively. <br>


 <br> The Trick: <br>
  A key element of the game is the "Trick call", which is an offer to increase the point bet in the current round. You can sing Truco on your turn during the outbound or return trip. If your team calls Trick and the opposing team accepts, the bet is doubled. If the opposing team sings "Retruco" and it is accepted, the bet is tripled. If the opposing team chants "Vale Cuatro" and it is accepted, the bet is quadrupled. The team that wins the round after accepting the last bet level wins the corresponding points. <br>

<br> End of the game: <br>
  Play continues until one team reaches the agreed upon number of points to win (usually 15, 30, or 40 points). The team that first reaches or exceeds that number of points is the winner. <br>

   <br> Additional rules: <br>

     <br> If a team calls Trick and the opposing team rejects it, the team that called Trick automatically wins a point. <br>
      If one team calls Trick and the opposing team calls "Vale Cuatro", the team that called Trick can accept or reject the bet. <br>
      Specific rules may vary depending on local traditions or player preferences, so be sure to agree on the rules before you start playing. <br>

<br><br>
  Remember that Truco Uruguayo is a fun, social game that often involves a high level of strategy and skill. Have fun playing!  </p>
            </div>
        </section>

        <!-- SECTION B  = cuadros-->
        <section class="pag4__sectionB">

            <!--cuadro 1-->
            <div class="pag4__sectionB__cuadro">
                <img class="pag4__cuadro__img" src="img/pag3/flor.jpg">
                <!--titulo-->
                <div class="pag4__cuadro__divH">
                    <h3 class="pag4__cuadro__h3">Flower</h3>
                </div>
                <!--texto-->
                <div class="pag4__cuadro__divP">
                    <p class="pag4__cuadro__p">
                    The Flower is a score in the trick that is separate from the trick but is very similar to the Envido. A player has Flower in the Argentine Trick when he has 3 cards of the same Suit </p>
                </div>
            </div>

            <!--cuadro 2-->
            <div class="pag4__sectionB__cuadro">
                <img class="pag4__cuadro__img" src="img/pag3/envido.jpg" >
                <!--titulo-->
                <div class="pag4__cuadro__divH">
                    <h3 class="pag4__cuadro__h3">Envido</h3>
                </div>
                <!--texto-->
                <div class="pag4__cuadro__divP">
                    <p class="pag4__cuadro__p">
                    The send is the sum of points when you have two cards of the same suit,
                         adds 20 <br>
                         Example: If I have a 6 and a 7 for coarse (13) I add 20 and it is 33 <br>
                    </p>
                </div>
            </div>

             <!--cuadro 3-->
            <div class="pag4__sectionB__cuadro">
                <img class="pag4__cuadro__img" src="img/pag3/truco.jpg">
                <!--titulo-->
                <div class="pag4__cuadro__divH">
                    <h3 class="pag4__cuadro__h3">Trick</h3>
                </div>
                <!--texto-->
                <div class="pag4__cuadro__divP">
                    <p class="pag4__cuadro__p">
                    The trick is the competition for whoever has the strongest hand, there is a competition between whoever wins 2 rounds or who wins one and wins another, it is the one who wins the hand.
                         Example: I (3 spades, 2 club, 4 cup) You (2 club, 2 cup, 5 cup) Here I would win because I can win the first one and then tie the last one with a 2 or tie the first one with a 2 and win the second with a 3.
                    </p>
                </div>
            </div>

        </section>

        <!-- SECTION C  = orden cartas-->
        <section class="pag4__sectionC">
            <h1 class="pag4__sectionC__h1">Order of the Cards</h1>
            <img class="pag3__sectionC__ordenCartasIMG" src="../en/img/pag3/valorarg.png"/>
        </section>
        <!--SECTION C2 = orden cartas-->
        <section class="pag4__sectionC2">
            <table border="1" class="pag4__tabla">
                <tr>
                    <td id="amarilloarg">Card</td>
                    <td id="amarilloarg">Type</td>
                    <td id="amarilloarg">Envido Value</td>
                </tr>
                <tr>
                    <td>1</td>
                    <td>Swords</td>
                    <td>1</td>
                </tr>
                <tr>
                    <td>1</td>
                    <td>Coarse</td>
                    <td>1</td>
                </tr>
                <tr>
                    <td>7</td>
                    <td>Swords</td>
                    <td>7</td>
                </tr>
                <tr>
                    <td>7</td>
                    <td>Gold</td>
                    <td>7</td>
                </tr>
                <tr>
                    <td>3</td>
                    <td>Any Type</td>
                    <td>3</td>
                </tr>
                <tr>
                    <td>2</td>
                    <td>Any type</td>
                    <td>2</td>
                </tr>
                <tr>
                    <td>1</td>
                    <td>Cup and Gold</td>
                    <td>1</td>
                </tr>
                <tr>
                    <td>12</td>
                    <td>Any Type</td>
                    <td>0</td>
                </tr>
                <tr>
                    <td>11</td>
                    <td>Any Type</td>
                    <td>0</td>
                </tr>
                <tr>
                    <td>10</td>
                    <td>Any Type</td>
                    <td>0</td>
                </tr>
                <tr>
                    <td>7</td>
                    <td>Cup and Coarse</td>
                    <td>7</td>
                </tr>
                <tr>
                    <td>6</td>
                    <td>Any Type</td>
                    <td>6</td>
                </tr>
                <tr>
                    <td>5</td>
                    <td>Any Type</td>
                    <td>5</td>
                </tr>
                <tr>
                    <td>4</td>
                    <td>Any Type</td>
                    <td>4</td>
                </tr>

            </table>
        </section>

    </main>

    <!--footer-->
    <footer class="pag__footer">
        <!--<hr class="pag2__footer__hr">-->

        <section class="pag__footer__content">
            <div class="pag__footer__divNombres">
                <p>Rodrigo Laviano</p>
                <p>Lautaro Rostan</p>
                <p>Nazareno Arcieri</p>
            </div>

            <div class="pag__footer__fivRedes">
                <a href="https://www.facebook.com/profile.php?id=100095268915630">
                    <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-brand-facebook" width="44" height="44" viewBox="0 0 24 24" stroke-width="1.5" stroke="#2c3e50" fill="none" stroke-linecap="round" stroke-linejoin="round">
                    <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                    <path d="M7 10v4h3v7h4v-7h3l1 -4h-4v-2a1 1 0 0 1 1 -1h3v-4h-3a5 5 0 0 0 -5 5v2h-3" />
                    </svg>
                </a>
                <a href="https://www.instagram.com/wikitruco/">
                    <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-brand-instagram" width="44" height="44" viewBox="0 0 24 24" stroke-width="1.5" stroke="#2c3e50" fill="none" stroke-linecap="round" stroke-linejoin="round">
                        <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                        <path d="M4 4m0 4a4 4 0 0 1 4 -4h8a4 4 0 0 1 4 4v8a4 4 0 0 1 -4 4h-8a4 4 0 0 1 -4 -4z" />
                        <path d="M12 12m-3 0a3 3 0 1 0 6 0a3 3 0 1 0 -6 0" />
                        <path d="M16.5 7.5l0 .01" />
                    </svg>
                </a>
                <a href="https://twitter.com/WikiTruco2023">
                    <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-brand-twitter" width="44" height="44" viewBox="0 0 24 24" stroke-width="1.5" stroke="#2c3e50" fill="none" stroke-linecap="round" stroke-linejoin="round">
                        <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                        <path d="M22 4.01c-1 .49 -1.98 .689 -3 .99c-1.121 -1.265 -2.783 -1.335 -4.38 -.737s-2.643 2.06 -2.62 3.737v1c-3.245 .083 -6.135 -1.395 -8 -4c0 0 -4.182 7.433 4 11c-1.872 1.247 -3.739 2.088 -6 2c3.308 1.803 6.913 2.423 10.034 1.517c3.58 -1.04 6.522 -3.723 7.651 -7.742a13.84 13.84 0 0 0 .497 -3.753c0 -.249 1.51 -2.772 1.818 -4.013z" />
                    </svg>
                </a>
            </div>
            </div>
        </section>
    </footer>
</body>
</html>
