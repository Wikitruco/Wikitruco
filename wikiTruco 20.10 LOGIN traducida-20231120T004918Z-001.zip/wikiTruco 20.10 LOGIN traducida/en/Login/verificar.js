const passwordInput = document.getElementById("password");
const passwordMessage = document.getElementById("passwordMessage");
const passwordLenght = document.getElementById("passwordLenght")
const passwordSpecial = document.getElementById("passwordSpecial")
const passwordNumber = document.getElementById("passwordNumber")
const passwordUpper = document.getElementById("passwordUpper")
const passwordLower = document.getElementById("passwordLower")

const form = document.getElementById("registration-form");

const userInput = document.getElementById("username");
const  userLenght= document.getElementById("userLenght")
const userSpecial = document.getElementById("user!Special")

const output = document.getElementById("Output")

var userValid = false;
var passwordValid = false;




// Function to toggle the password input type
function togglePasswordVisibility() {
    if (passwordInput.type === 'password') {
        passwordInput.type = 'text';

    } else {
        passwordInput.type = 'password';

    }
}

/*
function main() {
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    // Validaciones del formulario
    if (/[!@#$%^&*(),.?":{}|<>]/.test(username)) {
        alert('El nombre de usuario no debe contener signos de puntuación.');
        return;
    }

    if (password.length <= 6) {
        alert('La contraseña debe tener más de 6 caracteres.');
        return;
    }

    if (!/[A-Z]/.test(password)) {
        alert('La contraseña debe contener al menos una letra mayúscula.');
        return;
    }

    if (!/[a-z]/.test(password)) {
        alert('La contraseña debe contener al menos una letra minúscula.');
        return;
    }

    if (!/\d/.test(password)) {
        alert('La contraseña debe contener al menos un número.');
        return;
    }


}
*/

function main(){
    if(userValid && passwordValid){

    }else{

    }
}

// Enlazar la función main al botón en el HTML
//document.getElementById('submit-button').addEventListener('click', main);
form.addEventListener('submit', function(event) {
    // Verificar tu condición (por ejemplo, si el campo de entrada está vacío)
    if (!(userValid && passwordValid)) {
        // Evitar el envío del formulario
        event.preventDefault();

    }
});


function validatePassword() {
    const password = passwordInput.value;
    const containsNumber = /[0-9]/.test(password);
    const containsSpecialChar = /[!@#$%^&*()_+{}\[\]:;<>,.?~\\/\-|=]/.test(password);
    const containsLowercase = /[a-z]/.test(password);
    const containsUppercase = /[A-Z]/.test(password);
    const isLengthValid = password.length >= 6;
    if(isLengthValid){
        passwordLenght.textContent = "✔ Al menos seis caracteres"
        passwordLenght.style.color = "green"

    }else{
        passwordLenght.textContent = "❌ Al menos seis caracteres"
        passwordLenght.style.color = "red"

    }

    if(containsNumber){
        passwordNumber.textContent = "✔ Contiene al menos un numero"
        passwordNumber.style.color = "green"
    }else{
        passwordNumber.textContent = "❌ Contiene al menos un numero"
        passwordNumber.style.color = "red"

    }

    if(containsSpecialChar){
        passwordSpecial.textContent = "✔ Contiene al menos un caracter especial"
        passwordSpecial.style.color = "green"
    }else{
        passwordSpecial.textContent = "❌ Contiene al menos un caracter especial"
        passwordSpecial.style.color = "red"
    }

    if(containsLowercase){
        passwordLower.textContent = "✔ Contiene al menos una letra minuscula"
        passwordLower.style.color = "green"
    }else{
        passwordLower.textContent = "❌ Contiene al menos una letra minuscula"
        passwordLower.style.color = "red"
    }

    if(containsUppercase){
        passwordUpper.textContent = "✔ Contiene al menos una letra mayuscula"
        passwordUpper.style.color = "green"
    }else{
        passwordUpper.textContent = "❌ Contiene al menos una letra mayuscula"
        passwordUpper.style.color = "red"
    }

    if (containsNumber && containsSpecialChar && containsLowercase && containsUppercase && isLengthValid) {
        passwordValid = true
    } else {
        passwordValid = false
    }
}

function validateUsername(){
    const username = userInput.value;
    const containsSpecialChar = /[!@#$%^&*()_+{}\[\]:;<>,.?~\\/\-|=]/.test(username);
    const isLengthValid = username.length >= 6;

    if(containsSpecialChar){
        userSpecial.textContent = "❌ Username does not contain special characters"
        userSpecial.style.color = "red"
    }else{
        userSpecial.textContent = "✔ Username does not contain special characters"
        userSpecial.style.color = "green"
    }

    if(isLengthValid){
        userLenght.textContent = "✔ Username contains at least 6 characters"
        userLenght.style.color = "green"
    }else{
        userLenght.textContent = "❌ Username contains at least 6 characters"
        userLenght.style.color = "red"
    }

    if(!containsSpecialChar && userLenght){
        userValid = true;
    }else{
        userValid = false;
    }
}
/*
function request() {
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    const output = document.getElementById('output'); // Assuming you have an element with this ID

    // Create a new XMLHttpRequest
    const xhr = new XMLHttpRequest();

    // Define the callback function for when the request completes
    xhr.onload = function() {
        if (xhr.status === 200) {
            // Request was successful, handle the response
            const response = JSON.parse(xhr.responseText);

            if (response.success) {
                output.textContent = "Registro Exitoso!";
                output.style.color = "green";

                // Redirect after a successful registration
                window.location.href = '../index.php';
            } else {
                output.textContent = "Hubo un error en el registro.";
                output.style.color = "red";
            }
        } else {
            // Handle non-200 status codes (e.g., server errors)
            output.textContent = "Hubo un error en el registro. Código de estado: " + xhr.status;
            output.style.color = "red";
        }
    };

    // Handle network errors
    xhr.onerror = function() {
        output.textContent = "Error en la solicitud AJAX.";
        output.style.color = "red";
    };

    // Set up the POST request
    xhr.open('POST', 'register_process.php', true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

    // Encode and send the data
    const data = `username=${encodeURIComponent(username)}&password=${encodeURIComponent(password)}`;
    xhr.send(data);
}
*/


/*
function request(){
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    // Realizar solicitud AJAX si las validaciones son exitosas
    const xhr = new XMLHttpRequest();
    xhr.open('POST', './register_process.php', true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

    xhr.onload = function() {
        if (xhr.status === 200) {
            // Manejar la respuesta del servidor (si es necesario)
            alert('Registro exitoso');
        } else {
            alert('Hubo un error en el registro.');
        }
    };

    const data = `username=${encodeURIComponent(username)}&password=${encodeURIComponent(password)}`;
    xhr.send(data);
}*/
