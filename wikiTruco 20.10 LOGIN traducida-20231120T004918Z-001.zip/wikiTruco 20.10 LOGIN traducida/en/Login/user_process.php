<?php
// Iniciar la sesión
session_start();

include('db_config.php');
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Obtener la contraseña actual, nueva contraseña y ruta de la imagen de POST
    $contraseñaActual = $_POST["contraseñaActual"];
    $nuevaContraseña = $_POST["nuevaContraseña"];
    $imagePath = $_POST["imagePath"];

    // Obtener el nombre de usuario de la sesión (esto debe coincidir con tu estructura de sesión)
    $nombreUsuario = $_SESSION['username'];

    // Verificar que la contraseña actual es correcta
    $sql = "SELECT password, id FROM users WHERE username = '$nombreUsuario'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $contraseñaAlmacenada = $row["password"];
        $usuarioID = $row["id"];

        if (password_verify($contraseñaActual, $contraseñaAlmacenada)) {
            // La contraseña actual es correcta, hashear la nueva contraseña
            $hashNuevaContraseña = password_hash($nuevaContraseña, PASSWORD_DEFAULT);

            // Actualizar la contraseña hasheada y la ruta de la imagen
            $sql = "UPDATE users SET password = '$hashNuevaContraseña', image_path = '$imagePath' WHERE id = $usuarioID";

            if ($conn->query($sql) === TRUE) {
                // Éxito, redirigir de nuevo a user.php con un mensaje de éxito
                $_SESSION['mensaje_exito'] = "Registro actualizado con éxito.";
                header("Location: user.php");
                exit();
            } else {
                // Error en la actualización, redirigir de nuevo a user.php con un mensaje de error
                $_SESSION['mensaje_error'] = "Error al actualizar el registro: " . $conn->error;
                header("Location: user.php");
                exit();
            }
        } else {
            // Contraseña actual incorrecta, redirigir de nuevo a user.php con un mensaje de error
            $_SESSION['mensaje_error'] = "La contraseña actual es incorrecta.";
            header("Location: user.php");
            exit();
        }

    } else {
        echo "Usuario no encontrado en la base de datos.";
    }
}

// Cerrar la conexión a la base de datos
$conn->close();
?>
