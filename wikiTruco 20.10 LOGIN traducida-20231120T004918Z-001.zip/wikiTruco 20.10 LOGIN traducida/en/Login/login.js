var passwordInput = document.getElementById('password');


// Function to toggle the password input type
function togglePasswordVisibility() {
    if (passwordInput.type === 'password') {
        passwordInput.type = 'text';
    } else {
        passwordInput.type = 'password';
    }
}


document.getElementById('loginForm').addEventListener('submit', function (event) {
    event.preventDefault();

    var username = document.getElementById('username').value;
    var password = document.getElementById('password').value;

    var xhr = new XMLHttpRequest();
    xhr.open('POST', 'login_process.php', true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

    xhr.onload = function () {
        if (xhr.status === 200) {
            try {
                var response = JSON.parse(xhr.responseText);

                if (response.success) {
                    var messageDiv = document.getElementById('message');
                    messageDiv.innerHTML = 'Inicio de sesión exitoso. Redirigiendo...';
                    messageDiv.style.color = "green";
                    setTimeout(function() {
                        window.location.href = '../index.php';
                    }, 1000); // Redirect after 1 second
                } else {
                    var messageDiv = document.getElementById('message');
                    messageDiv.style.color = "red";
                    messageDiv.innerHTML = 'Error: ' + response.message;
                }
            } catch (e) {
                console.error('Invalid JSON response:', xhr.responseText);
            }
        } else {
            console.error('Request failed with status:', xhr.status);
        }
    };

    xhr.onerror = function () {
        console.error('Network error occurred');
    };

    xhr.send('username=' + username + '&password=' + password);
});
