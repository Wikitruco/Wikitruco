<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesión</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link href="./css/style.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Staatliches&family=Work+Sans:wght@400;700&display=swap" rel="stylesheet">

</head>
<body>

    <nav class="pag__nav">

    <div class="pag__nav__div__img">
            <a class="pag__nav__imgLink" href="../index.php">
                <img class="pag__nav__img" src="img/pag1/logo.png">
            </a>
        </div>
        <div class="pag__nav__div__a">
            <a href="../index.php" class="pag__nav__a">Inicio</a>
            <a href="../historia.php" class="pag__nav__a">Historia</a>
            <a href="../uruguayo.php" class="pag__nav__a">Uruguayo</a>
            <a href="../argentino.php" class="pag__nav__a">Argentino</a>

        </div>
    </nav>


    <div class="container mt-5">
        <div class="row">
            <div class="col-md-6">
                <h1>Iniciar Sesión</h1>
                <form id="loginForm">
                    <br>
                    <div class="form-group">
                        <label for="username">Nombre de usuario:</label>
                        <br>
                        <input type="text" style="border-width: 2px; border-color: #999" class="form-control" id="username" name="username" required>
                    </div>
                    <br>
                    <div class="form-group">
                        <label for="password">Contraseña:</label>
                        <br>
                        <div class="input-group mb-3">

                            <input type="password" style="border-width: 2px; border-color: #999" class="form-control" id="password" name="password" required>
                            <button onclick="togglePasswordVisibility()" class="btn btn-outline-secondary" type="button" id="button-addon1">
                                <svg xmlns="http://www.w3.org/2000/svg" width="27" height="23" fill="currentColor" class="bi bi-eye" viewBox="0 0 16 16">
                                <path d="M16 8s-3-5.5-8-5.5S0 8 0 8s3 5.5 8 5.5S16 8 16 8zM1.173 8a13.133 13.133 0 0 1 1.66-2.043C4.12 4.668 5.88 3.5 8 3.5c2.12 0 3.879 1.168 5.168 2.457A13.133 13.133 0 0 1 14.828 8c-.058.087-.122.183-.195.288-.335.48-.83 1.12-1.465 1.755C11.879 11.332 10.119 12.5 8 12.5c-2.12 0-3.879-1.168-5.168-2.457A13.134 13.134 0 0 1 1.172 8z"/>
                                <path d="M8 5.5a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5zM4.5 8a3.5 3.5 0 1 1 7 0 3.5 3.5 0 0 1-7 0z"/>
                                </svg>
                            </button>

                        </div>
                    </div>
                    <br>
                    <h3 id="message"></h3>
                    <br>
                    <button type="submit" class="btn btn-outline-warning btn-lg"><h3>Iniciar Sesión</h3></button>
                    <br><br>
                    <h4>No tienes cuenta? <a href="./register.php" style="color: blue">registrate aqui</a></h4>

                </form>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <script src="./login.js"></script>
</body>
</html>
