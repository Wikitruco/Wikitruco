<?php
session_start();

// Verificar si el usuario ha iniciado sesión
if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true) {
    $username = $_SESSION['username'];
    echo "Bienvenido, $username";
} else {
    // Si el usuario no ha iniciado sesión, redirigir a la página de inicio de sesión
    header('Location: login.php');
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Página de inicio</title>
</head>
<body>
    <h1>Página de inicio</h1>
    <!-- Aquí puedes mostrar el contenido de tu página de inicio -->
</body>
</html>
