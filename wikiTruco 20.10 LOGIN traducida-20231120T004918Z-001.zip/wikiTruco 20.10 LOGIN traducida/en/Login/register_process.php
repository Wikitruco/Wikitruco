<?php
// Configuración de la base de datos
$host = "localhost";
$username = "root";
$password = "root";
$database = "fede";

$conn = new mysqli($host, $username, $password, $database);

// Verificar la conexión
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

// Aquí continuará el código para procesar el formulario y guardar los datos en la base de datos

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];

    // Comprobar si el nombre de usuario ya existe en la base de datos
    $checkUserQuery = "SELECT username FROM users WHERE username = '$username'";
    $result = $conn->query($checkUserQuery);

    if ($result->num_rows > 0) {

        $error = "El nombre de usuario ya está en uso. Por favor, elige otro.";
        $boton = "Volver al Registro";
        $hipervinculo = "./register.php";
    } else {
        // Hash de la contraseña (para mayor seguridad)
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        // Consulta SQL para insertar datos en la base de datos
        $insertQuery = "INSERT INTO users (username, password) VALUES ('$username', '$hashedPassword')";

        // Ejecutar la consulta de inserción
        if ($conn->query($insertQuery) === TRUE) {
            $error = "Te has registrado exitosamente como <b> $username! </b>";
            $boton = "Loguearse";
            $hipervinculo = "./login.php";
        } else {
            echo "Error al registrar: " . $conn->error;
        }
    }
}

$conn->close();
?>


<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrarse</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="./css/style.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Staatliches&family=Work+Sans:wght@400;700&display=swap" rel="stylesheet">

</head>
<body>

<!--NAV-->
<nav class="pag__nav">

    <div class="pag__nav__div__img">
        <a class="pag__nav__imgLink" href="../index.php">
            <img class="pag__nav__img" src="img/pag1/logo.png">
        </a>
    </div>

    <div class="pag__nav__div__a">
        <a href="../index.php" class="pag__nav__a">Inicio</a>
        <a href="../historia.php" class="pag__nav__a">Historia</a>
        <a href="../uruguayo.php" class="pag__nav__a">Uruguayo</a>
        <a href="../argentino.php" class="pag__nav__a">Argentino</a>
    </div>
</nav>

<div class="container d-flex align-items-center justify-content-center" style="height: 100vh;">
    <div class="square bg-warning d-flex align-items-center justify-content-center rounded-5">
        <div class="text-center">
            <?php
                echo '<h1 class="text-center" id="texto">"' . $error . '"</h1>'
            ?>

            <br>
            <br>
            <div class="d-grid gap-2 col-6 mx-auto">
                <?php
                    echo '<a href="' . $hipervinculo . '">';
                    echo '<button class="btn btn-lg btn-success">';
                    echo '<h3>' . $boton . '</h3>';
                    echo '</button>';
                    echo '</a>';
                ?>

            </div>
        </div>
    </div>
</div>

<style>

    #texto {
        color: black;
        font-size: 26px;
    }

    .square {

        width: 850px;
        height: 400px;
    }
</style>


</body>
</html>
