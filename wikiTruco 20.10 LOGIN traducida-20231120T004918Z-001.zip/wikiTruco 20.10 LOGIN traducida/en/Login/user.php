<?php
session_start();
if (!isset($_SESSION['username'])) {
    // El usuario no ha iniciado sesión, redirige a register.php
    header("Location: register.php");
    exit(); // Asegura que el script se detenga después de la redirección
}



$user = $_SESSION["username"];
$logo = '<svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" class="bi bi-person-circle" viewBox="0 0 16 16">
<path d="M11 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0z"/>
<path fill-rule="evenodd" d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8zm8-7a7 7 0 0 0-5.468 11.37C3.242 11.226 4.805 10 8 10s4.757 1.225 5.468 2.37A7 7 0 0 0 8 1z"/>
</svg>'

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Configuración de Usuario</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Staatliches&family=Work+Sans:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="./css/user-style.css">


    <style>
        .rounded-image {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            object-fit: cover;
        }
        .center-vertically {
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
    </style>
</head>
<body>

   <!--NAV-->
   <nav class="pag__nav">

<div class="pag__nav__div__img"> <a class="pag__nav__imgLink" href="index.php"><img class="pag__nav__img" src="img/pag1/logo.png"></a></div>

<div class="pag__nav__div__a">

    <a href="../index.php" class="pag__nav__a">Inicio</a>
    <a href="../campeonatos.php" class="pag__nav__a">Campeonatos</a>
    <a href="../historia.php" class="pag__nav__a">Historia</a>
    <a href="../uruguayo.php" class="pag__nav__a">Uruguayo</a>
    <a href="../argentino.php" class="pag__nav__a">Argentino</a>

    <?php

        if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true) {
            echo '<a href="./user.php" class="pag__nav__a">' . $logo .'</a>';
        }
    ?>

</div>

</nav>


<div class="container center-vertically">
        <div class="col-md-8">
            <h1 class="text-center mt-4 text-nowrap ">Configuración de Usuario</h1>
            <br>
            <h2>Cambiar Contraseña</h2>
            <br>
            <form action="./user_process.php" method="POST">
                <div class="form-group">
                    <label for="contrasena-actual">Contraseña actual</label>
                    <input name="contraseñaActual" type="password" class="form-control" id="contrasena-actual" placeholder="Tu contraseña actual">
                </div>
                <div class="form-group">
                    <label for="contrasena-nueva">Contraseña nueva</label>
                    <input name="nuevaContraseña" type="password" class="form-control" id="contrasena-nueva" placeholder="Tu contraseña nueva">
                </div>
                <div class="form-group">
                    <label for="imagen">Subir Imagen</label>
                    <input name="imagePath" type="file" class="form-control-file" id="imagen">
                </div>
                <div class="form-group">
                    <label for="imagen-preview">Vista Previa de la Imagen</label>
                    <img id="imagen-preview" class="rounded-image" src="#" alt=".">
                </div>
                <div class="d-flex justify-content-between">
                    <button type="submit" class="btn btn-success">Guardar Cambios</button>
                    <a href="logout_process.php" class="btn btn-outline-dark">Cerrar Sesión</a>
                </div>
            </form>
            <br>
            <br>

            <?php
            if (isset($_SESSION['mensaje_exito'])) {
                echo '<div class="alert alert-success">' . $_SESSION['mensaje_exito'] . '</div>';
                unset($_SESSION['mensaje_exito']); // Limpiar el mensaje de éxito
            }

            // Verificar si hay un mensaje de error
            if (isset($_SESSION['mensaje_error'])) {
                echo '<div class="alert alert-danger">' . $_SESSION['mensaje_error'] . '</div>';
                unset($_SESSION['mensaje_error']); // Limpiar el mensaje de error
            }
            ?>
        </div>
    </div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

<script>
    // JavaScript para mostrar la vista previa de la imagen
    const imagenInput = document.getElementById('imagen');
    const imagenPreview = document.getElementById('imagen-preview');

    imagenInput.addEventListener('change', function () {
        const file = imagenInput.files[0];
        if (file) {
            const imageUrl = URL.createObjectURL(file);
            imagenPreview.src = imageUrl;
        }
    });


</script>






    <!--footer-->
<footer class="pag__footer">
    <!--<hr class="pag2__footer__hr">-->

    <section class="pag__footer__content">
        <div class="pag__footer__divNombres">
            <p>Lautaro Rostan</p>
            <p>Nazareno Arcieri</p>
        </div>

        <div class="pag__footer__fivRedes">
            <a href="#">
                <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-brand-facebook" width="44" height="44" viewBox="0 0 24 24" stroke-width="1.5" stroke="#2c3e50" fill="none" stroke-linecap="round" stroke-linejoin="round">
                <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                <path d="M7 10v4h3v7h4v-7h3l1 -4h-4v-2a1 1 0 0 1 1 -1h3v-4h-3a5 5 0 0 0 -5 5v2h-3" />
                </svg>
            </a>
            <a href="#">
                <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-brand-instagram" width="44" height="44" viewBox="0 0 24 24" stroke-width="1.5" stroke="#2c3e50" fill="none" stroke-linecap="round" stroke-linejoin="round">
                    <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                    <path d="M4 4m0 4a4 4 0 0 1 4 -4h8a4 4 0 0 1 4 4v8a4 4 0 0 1 -4 4h-8a4 4 0 0 1 -4 -4z" />
                    <path d="M12 12m-3 0a3 3 0 1 0 6 0a3 3 0 1 0 -6 0" />
                    <path d="M16.5 7.5l0 .01" />
                </svg>
            </a>
            <a href="#">
                <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-brand-twitter" width="44" height="44" viewBox="0 0 24 24" stroke-width="1.5" stroke="#2c3e50" fill="none" stroke-linecap="round" stroke-linejoin="round">
                    <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                    <path d="M22 4.01c-1 .49 -1.98 .689 -3 .99c-1.121 -1.265 -2.783 -1.335 -4.38 -.737s-2.643 2.06 -2.62 3.737v1c-3.245 .083 -6.135 -1.395 -8 -4c0 0 -4.182 7.433 4 11c-1.872 1.247 -3.739 2.088 -6 2c3.308 1.803 6.913 2.423 10.034 1.517c3.58 -1.04 6.522 -3.723 7.651 -7.742a13.84 13.84 0 0 0 .497 -3.753c0 -.249 1.51 -2.772 1.818 -4.013z" />
                </svg>
            </a>
        </div>
    </section>
</footer>






</body>
</html>
