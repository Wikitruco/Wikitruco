<?php
session_start();
include('db_config.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM users WHERE username = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $row = $result->fetch_assoc();
        $stored_password_hash = $row['password'];
        if (password_verify($password, $stored_password_hash)) {
            // Contraseña válida, establecer las variables de sesión
            $_SESSION['loggedin'] = true;
            $_SESSION['username'] = $username;
            $response = array("success" => true);
        } else {
            $response = array("success" => false, "message" => "Usuario o contraseña incorrectos.");
        }
    } else {
        $response = array("success" => false, "message" => "Usuario o contraseña incorrectos.");
    }

    header('Content-Type: application/json');
    echo json_encode($response);
}
?>
