<?php
session_start();
$logo = '<svg xmlns="http://www.w3.org/2000/svg" width="30" height="18" fill="currentColor" class="bi bi-person-circle" viewBox="0 0 16 16">
<path d="M11 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0z"/>
<path fill-rule="evenodd" d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8zm8-7a7 7 0 0 0-5.468 11.37C3.242 11.226 4.805 10 8 10s4.757 1.225 5.468 2.37A7 7 0 0 0 8 1z"/>
</svg>'

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tournament</title>
    <link rel="shortcut icon" href="img/pag1/icono.jpg">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Staatliches&family=Work+Sans:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="./css/normalize.css">
    <link rel="stylesheet" href="./css/style.css">

</head>
<body>

     <!--NAV-->
     <nav class="pag__nav">
        <div class="pag__nav__div__img"> <a class="pag__nav__imgLink" href="index.php"><img class="pag__nav__img" src="img/pag1/logo.png"></a></div>
        <div class="pag__nav__div__a">
            <a href="enindex.php" class="pag__nav__a">Home</a>
            <a href="enhistoria.php" class="pag__nav__a">History</a>
            <a href="enuruguayo.php" class="pag__nav__a">Uruguayan</a>
            <a href="enargentino.php" class="pag__nav__a">Argentinian</a>
            <a href="../es/campeonatos.php" class="pag1__a">ES</a>
            <?php
                if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true) {

                    echo '<a href="./Login/user.php" class="pag__nav__a">' . $_SESSION["username"] . $logo .'</a>';

                }else{
                    echo '<a href="./Login/user.php" class="pag__nav__a">Cuenta</a>';
                }
            ?>
        </div>
    </nav>

    <header>
        <img src="img/pag5/gentetruquito.jpg" class="pag2__header__img" width="900px" height="700px">
    </header>

    <main class="pag5_main">

        <div class="grid-container">
            <div class="grid-item">
                <h3>Categories:</h3>
                <p>Trick championships usually have different categories or divisions, depending on the skill level of the players. There may be competitions for beginner, intermediate and advanced players.</p>
            </div>
            <div class="grid-item">
                <h3>Organization: </h3>
                <p>These championships can be organized by clubs, trick associations or sports institutions. There are often local, regional and national tournaments, and winners of local competitions can qualify for higher level competitions.</p>
            </div>
            <div class="grid-item">
                <h3>Awards: </h3>
                <p>Trick championships often offer cash prizes, trophies, medals, or other incentives for winners and runners-up. Prizes may vary depending on the size of the tournament.</p>
            </div>
            <div class="grid-item">
                <h3>Diffusion: </h3>
                <p>Some trick championships are televised or streamed online, giving them greater visibility. This has contributed to the trick being an even more popular game in some regions.</p>
            </div>
            <div class="grid-item">
                <h3>Culture and Community: </h3>
                <p>Trick is not only a game, but also an important part of culture in some countries. Players often form communities and clubs dedicated to the trick, and championships are occasions to socialize and demonstrate skills.</p>
            </div>
            <div class="grid-item">
                <h3>Skills and Strategies: </h3>
                <p>To be successful in a trick championship, a combination of cardiac skills, strategy, memory and the ability to read the opponent's signs is required. Experienced players can anticipate their opponents' movements and use signs to communicate with their teammate effectively.</p>
            </div>
        </div>



        <section class="pag5__sectionB">
            <div class="pag5__sectionB__divImg">
                <img class="pag5__sectionB__divImg__img" src="img/pag5/invitetotruco.png" >
            </div>
            <div class="pag5__sectionB__divText">
                <h1 >Uruguayan Trick Tournament</h1>
                <h2 class="h1">Date: <b>16/11</b></h2>
                <h2 class="h1">Tournament Information</h2>
                <h3 class="premios">Awards</h3>
                <p class="premios">
                    <b>1st</b> Asado for 2 people and a Red Label whiskey<br>
                    <b>2nd</b> 2 wallet Polo with U$S 12<br>
                    <b>3rd</b> U$S20 <br>
                    <br>
                    By just paying the registration you participate in a 125 0km city motorcycle tournament
                </p>
                <h2 class="h1">Rules</h2>
                <p>
                    <h4>Article 1 - AUTHORITIES: </h4> The tournament will have a jury headed by the President of the Institution, who will designate two (2) partners to form a commission that, in addition to supervising the gaming tables, appointing for this purpose a partner - free of play - as a observer, will determine the completion of the different rounds, will credit the scores and will ultimately be in charge of determining the positions to obtain the planned prizes and which will be duly announced before the start of the game. event.<br>

                     <h4>Article 2 - DISPUTES: </h4> In the event of any type of dispute that may arise between the opponents, they must be submitted to the decision of the designated observer, and so that, if necessary, they are not satisfied, the respective appeal will be admitted, which will be elucidated immediately by the Commission designated in accordance with the previous article, its decision being irrevocable and of last resort, and the players must abide by it, and if not, with the possibility of being separated from the tournament, these circumstances will be remembered. before the start of the games, reminding the participants that under no circumstances will the climate of camaraderie, respect and friendship that prevails forever in the Timón Club be disturbed.<br>

                     <h4>Article 3 - NUMBER OF PLAYERS: </h4> Each team will be made up of three (3) people, regardless of sex, who will sit alternately, with the hand on the right to deal cards, passing at once for each participant.<br>

                     <h4>Article 4 - STARTING FORM: </h4> To establish who will be the first to give cards, each one will take a card from the deck, with the one who obtains the highest score being the one who will begin the game, continuing the hand in the manner mentioned in the previous article.- In case of a tie, only among the participants the operation will be repeated until only one with a higher score results.<br>

                     <h4>Article 5 - FORM OF GAME: </h4> Matches will be played consisting of obtaining Fifteen (15) first points called “BAD” and Fifteen (15) next points called “GOOD”, and once the latter are completed, whoever whoever achieves them first will be the winner.- Until the first Five (5) points (Bad) are obtained, they will play together as called “ROUND” and after one of the teams obtains Ten (10) points of the second stage ( Good) also until the game is completed and a winner emerges.- After the first Five (5) Bad points, mentioned and until reaching the other Ten (10) Good points, games will be played alternately between all (round) or in a individual, those that are facing each other from different teams, called “Pica a Pica”, and in which the “Falta Envido” will have a unique value, if desired, for the winner of Six (6) points only.<br >

                     <h4>Article 6 - SCORES: </h4> It will not be played with “FLOWER”, and in the event that a player obtains the three (3) cards of the same suit, for the “Point” he must score exclusively the highest score that he adds with two (2) cards, not being able to call a minor point, although if he remained “standing” he would win by singing the minor point. - If it is determined that this occurred, he will lose the score he would have obtained, which will be recorded for the opposing team. <br>
                </p>
            </div>

        </section>
    </main>

     <!--footer-->
     <footer class="pag__footer">
        <!--<hr class="pag2__footer__hr">-->

        <section class="pag__footer__content">
            <div class="pag__footer__divNombres">
                <p>Nazareno Arcieri</p>
                <p>Lautaro Rostan</p>
            </div>

            <div class="pag__footer__fivRedes">
                <a href="https://www.facebook.com/profile.php?id=100095268915630">
                    <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-brand-facebook" width="44" height="44" viewBox="0 0 24 24" stroke-width="1.5" stroke="#2c3e50" fill="none" stroke-linecap="round" stroke-linejoin="round">
                    <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                    <path d="M7 10v4h3v7h4v-7h3l1 -4h-4v-2a1 1 0 0 1 1 -1h3v-4h-3a5 5 0 0 0 -5 5v2h-3" />
                    </svg>
                </a>
                <a href="https://www.instagram.com/wikitruco/">
                    <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-brand-instagram" width="44" height="44" viewBox="0 0 24 24" stroke-width="1.5" stroke="#2c3e50" fill="none" stroke-linecap="round" stroke-linejoin="round">
                        <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                        <path d="M4 4m0 4a4 4 0 0 1 4 -4h8a4 4 0 0 1 4 4v8a4 4 0 0 1 -4 4h-8a4 4 0 0 1 -4 -4z" />
                        <path d="M12 12m-3 0a3 3 0 1 0 6 0a3 3 0 1 0 -6 0" />
                        <path d="M16.5 7.5l0 .01" />
                    </svg>
                </a>
                <a href="https://twitter.com/WikiTruco2023">
                    <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-brand-twitter" width="44" height="44" viewBox="0 0 24 24" stroke-width="1.5" stroke="#2c3e50" fill="none" stroke-linecap="round" stroke-linejoin="round">
                        <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                        <path d="M22 4.01c-1 .49 -1.98 .689 -3 .99c-1.121 -1.265 -2.783 -1.335 -4.38 -.737s-2.643 2.06 -2.62 3.737v1c-3.245 .083 -6.135 -1.395 -8 -4c0 0 -4.182 7.433 4 11c-1.872 1.247 -3.739 2.088 -6 2c3.308 1.803 6.913 2.423 10.034 1.517c3.58 -1.04 6.522 -3.723 7.651 -7.742a13.84 13.84 0 0 0 .497 -3.753c0 -.249 1.51 -2.772 1.818 -4.013z" />
                    </svg>
                </a>
            </div>
        </section>
    </footer>


</body>
</html>
