#!/bin/bash
# juego.sh
clear

# Si pasamos como parámetro 'x', borramos el archivo de récords
if [ $# -ne 0 ]; then
   echo "Borrando fichero de récords"
   rm record.txt
fi

# Función para mostrar el menú
show_menu() {
    echo "Menú:"S
    echo "1. Jugar"
    echo "2. Ajustar Dificultad"
    echo "3. Salir"
}

while true; do
    show_menu
    read -p "Selecciona una opción: " choice

    case $choice in
        1)
            # Comenzar el juego
            contador=1
            minumero=$((1+RANDOM%40))
            echo "  "
            read -p "Dime tu nombre: " nombre
            echo "  "
            read -p "Llevas $contador intentos. Dime un número: " numero

            until [ $numero -eq $minumero ]; do
                if [ $numero -gt $minumero ]; then
                    echo -e "\e[31mEl número que has ingresado es mayor\e[0m"
                else
                    echo -e "\e[33mEl número que has ingresado es menor\e[0m"
                fi
                contador=$(($contador+1))
                read -p "Llevas $contador intentos. Dime un número: " numero
            done
            echo -e "\e[32mHas Acertado!!\e[0m"

            # Grabamos el récord en el archivo (primero intentos y luego nombre)
            echo $contador:$nombre >> record.txt
            # Ordenamos para dejar en orden por intentos y nos quedamos con las 3 primeras líneas
            sort -g record.txt | head > recordtemp.txt
            cp recordtemp.txt record.txt
            ;;
        2)
            # Ajustar dificultad (puedes implementar esta opción aquí)
            echo "Dificultad ajustada"
            ;;
        3)
            # Salir del juego
            echo "¡Hasta luego!"
            exit
            ;;
        *)
            echo "Opción no válida. Por favor, selecciona una opción válida."
            ;;
    esac
done
