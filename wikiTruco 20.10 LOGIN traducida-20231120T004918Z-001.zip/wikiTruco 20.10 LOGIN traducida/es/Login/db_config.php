<?php
$host = 'localhost';
$user = 'root';
$pass = 'root';
$dbname = 'fede';

$conn = new mysqli($host, $user, $pass, $dbname);

if ($conn->connect_error) {
    die("La conexión a la base de datos falló: " . $conn->connect_error);
}
?>
