<?php
session_start();

// Cierra la sesión si está abierta
if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true) {
    // Elimina todas las variables de sesión
    session_unset();

    // Destruye la sesión
    session_destroy();
}

// Redirige al usuario a la página de inicio (index.php) sin sesión iniciada
header("Location: ../index.php");
exit;
?>
