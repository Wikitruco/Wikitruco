<?php
session_start();
$logo = '<svg xmlns="http://www.w3.org/2000/svg" width="30" height="18" fill="currentColor" class="bi bi-person-circle" viewBox="0 0 16 16">
<path d="M11 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0z"/>
<path fill-rule="evenodd" d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8zm8-7a7 7 0 0 0-5.468 11.37C3.242 11.226 4.805 10 8 10s4.757 1.225 5.468 2.37A7 7 0 0 0 8 1z"/>
</svg>'

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Uruguayo</title>
    <link rel="shortcut icon" href="img/pag1/icono.jpg">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Staatliches&family=Work+Sans:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/normalize.css">
    <link rel="stylesheet" href="css/style.css">


</head>
<body>
    <!--NAV-->
    <nav class="pag__nav">
        <div class="pag__nav__div__img"> <a class="pag__nav__imgLink" href="index.php"><img class="pag__nav__img" src="img/pag1/logo.png"></a></div>
        <div class="pag__nav__div__a">
            <a href="index.php" class="pag__nav__a">Inicio</a>
            <a href="historia.php" class="pag__nav__a">Historia</a>
            <a href="campeonatos.php" class="pag__nav__a">Campeonatos</a>
            <a href="argentino.php" class="pag__nav__a">Argentino</a>
            <a href="../en/enuruguayo.php" class="pag1__a">EN</a>
            <?php



            if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true) {

                echo '<a href="./Login/user.php" class="pag__nav__a">' . $_SESSION["username"] . $logo .'</a>';

            }else{
                echo '<a href="./Login/user.php" class="pag__nav__a">Cuenta</a>';
            }


            ?>
        </div>
    </nav>

    <header class="pag3__header">
        <!--carrusel-->

    </header>

    <main class="pag3__main">

        <!-- SECTION A   = Reglas de juego-->
        <section class="pag3__sectionA">
            <div class="pag3__sectionA__divH2">
                <h2 class="pag3__sectionA__h2">Reglas de Juego</h2>
            </div>
            <div class="pag3__sectionA__divP">
                <p class="pag3__sectionA__p">
                    El Truco Uruguayo es un juego de cartas tradicionalmente jugado en Uruguay y algunas otras regiones de América Latina. A continuación, te proporciono un reglamento básico para jugar al Truco Uruguayo: <br> <br>

                  <span id="amarillo">  Baraja: </span> <br>
                    Se utiliza una baraja española de 40 cartas. Esta baraja excluye los 8 y los 9 de todos los palos. <br>

                  <br>  <span id="amarillo">Número de jugadores: </span> <br>
                    El Truco Uruguayo se juega típicamente con cuatro jugadores, organizados en dos equipos de dos personas cada uno. Los jugadores de cada equipo se sientan uno frente al otro. <br>
                    <br>
                    <span id="amarillo">Distribución de cartas:</span> <br>
                    Las cartas se distribuyen en sentido antihorario, comenzando por el jugador a la derecha del repartidor. Cada jugador recibe tres cartas en la primera ronda y luego se distribuyen cuatro cartas en las siguientes rondas. El repartidor cambia en cada ronda. <br>
                    <br>
                    <span id="amarillo">Desarrollo del juego:</span> <br>
                    El juego se desarrolla en rondas, y el objetivo es ganar la mayoría de las rondas. Cada ronda consta de dos partes: la "ida" y la "vuelta". <br>

                   <br> La ida: En la ida, los jugadores colocan una carta en el centro de la mesa, y el equipo que juega la carta más alta gana la ida. Si ambos equipos juegan cartas del mismo valor, la ida se empata y no se otorgan puntos. <br>

                   <br> La vuelta: En la vuelta, los jugadores colocan otra carta en el centro de la mesa, y el equipo que gana la vuelta se lleva los puntos correspondientes. El valor de las cartas en la vuelta es diferente del valor en la ida. Las cartas tienen los siguientes valores en la vuelta, de mayor a menor: 3, 2, 1 de Espadas, Copas y Oro, respectivamente. <br>


                   <br><span id="amarillo">El Truco:</span>  <br>
                    Un elemento clave del juego es "cantar Truco", que es una oferta para aumentar la apuesta de puntos en la ronda actual. Puedes cantar Truco en tu turno durante la ida o la vuelta. Si tu equipo canta Truco y el equipo contrario acepta, la apuesta se duplica. Si el equipo contrario canta "Retruco" y se acepta, la apuesta se triplica. Si el equipo contrario canta "Vale Cuatro" y se acepta, la apuesta se cuadruplica. El equipo que gane la ronda después de aceptar el último nivel de apuesta gana los puntos correspondientes. <br>

                  <br> <span id="amarillo">Fin del juego:</span>  <br>
                    El juego continúa hasta que un equipo alcance la cantidad de puntos acordada para ganar (generalmente 15, 30 o 40 puntos). El equipo que primero alcance o supere esa cantidad de puntos es el ganador. <br>

                     <br> <span id="amarillo">Reglas adicionales: </span><br>

                       <br> Si un equipo canta Truco y el equipo contrario lo rechaza, el equipo que cantó Truco gana un punto automáticamente. <br>
                        Si un equipo canta Truco y el equipo contrario canta "Vale Cuatro", el equipo que cantó Truco puede aceptar o rechazar la apuesta. <br>
                        Las reglas específicas pueden variar según las tradiciones locales o las preferencias de los jugadores, así que asegúrate de acordar las reglas antes de comenzar a jugar. <br>

<br>
                    Recuerda que el Truco Uruguayo es un juego social y divertido que a menudo involucra un alto nivel de estrategia y habilidad. ¡Diviértete jugando!
                </p>
            </div>
        </section>

        <!-- SECTION B  = cuadros-->
        <section class="pag3__sectionB">

            <!--cuadro 1-->
            <div class="pag3__sectionB__cuadro">
                <img class="pag3__cuadro__img" src="img/pag3/flor.jpg">
                <!--titulo-->
                <div class="pag3__cuadro__divH">
                    <h3 class="pag3__cuadro__h3">Flor</h3>
                </div>
                <!--texto-->
                <div class="pag3__cuadro__divP">
                    <p class="pag3__cuadro__p">
                        La Flor es una puntuacion en el truco que esta aparte del truco pero es muy similar al envido. Un jugador tiene Flor en el Truco Uruguayo cuando tiene alguna de estas opciones: <br><br>
                        3 cartas del mismo Palo <br>
                        2 cartas del mismo Palo y una Muestra <br>
                        2 o 3 Muestras
                    </p>
                </div>
            </div>

            <!--cuadro 2-->
            <div class="pag3__sectionB__cuadro">
                <img class="pag3__cuadro__img" src="img/pag3/envido.jpg" >
                <!--titulo-->
                <div class="pag3__cuadro__divH">
                    <h3 class="pag3__cuadro__h3">Envido</h3>
                </div>
                <!--texto-->
                <div class="pag3__cuadro__divP">
                    <p class="pag3__cuadro__p">
                        El envido es la suma de puntos cuando tenes dos cartas del mismo palo o una muestra y una carta cualquiera,
                        se suma 20 o el valor de la muestra mas el valor de la otra carta. <br>
                        Ejemplo: Si tengo un 6 y un 7 de basto (13) le sumo 20 y son 33 <br>
                        Otro ejemplo es si tengo el 2 de la muestra (30) y le sumo un 5 que tengo es 35.
                    </p>
                </div>
            </div>

             <!--cuadro 3-->
            <div class="pag3__sectionB__cuadro">
                <img class="pag3__cuadro__img" src="img/pag3/truco.jpg">
                <!--titulo-->
                <div class="pag3__cuadro__divH">
                    <h3 class="pag3__cuadro__h3">Truco</h3>
                </div>
                <!--texto-->
                <div class="pag3__cuadro__divP">
                    <p class="pag3__cuadro__p">
                        El truco es la competencia por eurul que tiene la mano mas fuerte, se compite haber quien gana 2 rondas o parda una y gana otra es el que gana la mano.
                        Ejemplo: Yo(3 espadas, 4 basto, 4 copa) Vos(2 basto, 2 copa, 5 copa) la muestra es el 7 de Basto aca ganas vos porque solo puedo ganarte a una carta mientras voz me ganas a 2
                    </p>
                </div>
            </div>

        </section>

        <!-- SECTION C  = orden cartas-->
        <section class="pag3__sectionC">
            <h1 class="pag3__sectionC__h1">Orden de las Cartas</h1>
            <img src="" class="pag3__sectionC__img">
            <img class="pag3__sectionC__ordenCartasIMG" src="../es/img/pag3/valoruru.png"/>



            <table border="1" class="pag3__tabla">
                <tr>
                    <td id="amarillo">Carta</td>
                    <td id="amarillo">Palo</td>
                    <td id="amarillo">Valor del Envido</td>
                </tr>
                <tr>
                    <td>2</td>
                    <td>Muestra</td>
                    <td>30</td>
                </tr>
                <tr>
                    <td>4</td>
                    <td>Muestra</td>
                    <td>29</td>
                </tr>
                <tr>
                    <td>5</td>
                    <td>Muestra</td>
                    <td>28</td>
                </tr>
                <tr>
                    <td>11</td>
                    <td>Muestra</td>
                    <td>27</td>
                </tr>
                <tr>
                    <td>10</td>
                    <td>Muestra</td>
                    <td>27</td>
                </tr>
                <tr>
                    <td>1</td>
                    <td>Espada</td>
                    <td>1</td>
                </tr>
                <tr>
                    <td>1</td>
                    <td>Basto</td>
                    <td>1</td>
                </tr>
                <tr>
                    <td>7</td>
                    <td>Espada</td>
                    <td>7</td>
                </tr>
                <tr>
                    <td>7</td>
                    <td>Oro</td>
                    <td>7</td>
                </tr>
                <tr>
                    <td>3</td>
                    <td>Cualquier Palo</td>
                    <td>3</td>
                </tr>
                <tr>
                    <td>2</td>
                    <td>No Muestra</td>
                    <td>2</td>
                </tr>
                <tr>
                    <td>1</td>
                    <td>Copa y Oro</td>
                    <td>1</td>
                </tr>
                <tr>
                    <td>12</td>
                    <td>Cualquier Palo</td>
                    <td>0</td>
                </tr>
                <tr>
                    <td>11</td>
                    <td>No Muestra</td>
                    <td>0</td>
                </tr>
                <tr>
                    <td>10</td>
                    <td>No Muestra</td>
                    <td>0</td>
                </tr>
                <tr>
                    <td>7</td>
                    <td>Copa y Basto</td>
                    <td>7</td>
                </tr>
                <tr>
                    <td>6</td>
                    <td>Cuaqlquier Palo</td>
                    <td>6</td>
                </tr>
                <tr>
                    <td>5</td>
                    <td>No Muestra</td>
                    <td>5</td>
                </tr>
                <tr>
                    <td>4</td>
                    <td>No Muestra</td>
                    <td>4</td>
                </tr>

            </table>

        </section>

    </main>

    <!--footer-->
    <footer class="pag__footer">
        <!--<hr class="pag2__footer__hr">-->

        <section class="pag__footer__content">
            <div class="pag__footer__divNombres">
                <p>Rodrigo Laviano</p>
                <p>Lautaro Rostan</p>
                <p>Nazareno Arcieri</p>
            </div>

            <div class="pag__footer__fivRedes">
                <a href="#">
                    <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-brand-facebook" width="44" height="44" viewBox="0 0 24 24" stroke-width="1.5" stroke="#2c3e50" fill="none" stroke-linecap="round" stroke-linejoin="round">
                    <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                    <path d="M7 10v4h3v7h4v-7h3l1 -4h-4v-2a1 1 0 0 1 1 -1h3v-4h-3a5 5 0 0 0 -5 5v2h-3" />
                    </svg>
                </a>
                <a href="#">
                    <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-brand-instagram" width="44" height="44" viewBox="0 0 24 24" stroke-width="1.5" stroke="#2c3e50" fill="none" stroke-linecap="round" stroke-linejoin="round">
                        <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                        <path d="M4 4m0 4a4 4 0 0 1 4 -4h8a4 4 0 0 1 4 4v8a4 4 0 0 1 -4 4h-8a4 4 0 0 1 -4 -4z" />
                        <path d="M12 12m-3 0a3 3 0 1 0 6 0a3 3 0 1 0 -6 0" />
                        <path d="M16.5 7.5l0 .01" />
                    </svg>
                </a>
                <a href="#">
                    <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-brand-twitter" width="44" height="44" viewBox="0 0 24 24" stroke-width="1.5" stroke="#2c3e50" fill="none" stroke-linecap="round" stroke-linejoin="round">
                        <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                        <path d="M22 4.01c-1 .49 -1.98 .689 -3 .99c-1.121 -1.265 -2.783 -1.335 -4.38 -.737s-2.643 2.06 -2.62 3.737v1c-3.245 .083 -6.135 -1.395 -8 -4c0 0 -4.182 7.433 4 11c-1.872 1.247 -3.739 2.088 -6 2c3.308 1.803 6.913 2.423 10.034 1.517c3.58 -1.04 6.522 -3.723 7.651 -7.742a13.84 13.84 0 0 0 .497 -3.753c0 -.249 1.51 -2.772 1.818 -4.013z" />
                    </svg>
                </a>
            </div>
        </section>
    </footer>
</body>
</html>
