<?php
session_start();
$logo = '<svg xmlns="http://www.w3.org/2000/svg" width="30" height="18" fill="currentColor" class="bi bi-person-circle" viewBox="0 0 16 16">
<path d="M11 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0z"/>
<path fill-rule="evenodd" d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8zm8-7a7 7 0 0 0-5.468 11.37C3.242 11.226 4.805 10 8 10s4.757 1.225 5.468 2.37A7 7 0 0 0 8 1z"/>
</svg>'

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Historia</title>
    <link rel="shortcut icon" href="img/pag1/icono.jpg">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Staatliches&family=Work+Sans:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/normalize.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body class="pag2">
    <!--NAV-->
    <nav class="pag__nav">

        <div class="pag__nav__div__img"> <a class="pag__nav__imgLink" href="index.php"><img class="pag__nav__img" src="img/pag1/logo.png"></a></div>

        <div class="pag__nav__div__a">

            <a href="index.php" class="pag__nav__a">Inicio</a>
            <a href="campeonatos.php" class="pag__nav__a">Campeonatos</a>
            <a href="uruguayo.php" class="pag__nav__a">Uruguayo</a>
            <a href="argentino.php" class="pag__nav__a">Argentino</a>
            <a href="../en/enhistoria.php" class="pag1__a">EN</a>
        
            <?php

                if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true) {

                    echo '<a href="./Login/user.php" class="pag__nav__a">' . $_SESSION["username"] . $logo .'</a>';

                }else{
                    echo '<a href="./Login/user.php" class="pag__nav__a">Cuenta</a>';
                }
            ?>

        </div>
    </nav>

    <header class="pag2__header">
        <img src="img/pag2/header.jpg" class="pag2__header__img">
    </header>

    <main class="pag2__main">

        <!--SECTION 1-->
        <section class="pag2__sectionA">
            <div class="pag2__section__divText pag2__sections__50">
                <h2 class="pag2__section__h2" id="pag2__section__h2__dark">Origen</h2>
                <p class="pag2__section__p">
                    La historia del truco se remonta al siglo XIX en Argentina y Uruguay. Se considera un juego de naipes criollo, nacido en los barrios marginales de Buenos Aires y Montevideo durante la época de la colonización española y la gran inmigración europea a la región.
                    <br>
                    El término "truco" proviene del español "truc", que significa "engaño" o "truco". Desde sus inicios, el juego se destacó por ser una forma de entretenimiento popular para la clase trabajadora y las personas comunes.
                    A lo largo del tiempo, el truco se convirtió en un símbolo importante de la cultura argentina y uruguaya, presente en reuniones familiares, eventos sociales y competiciones amistosas. Su popularidad ha trascendido las fronteras de ambos países, llegando a ser conocido en otras naciones de América Latina debido a la migración y el intercambio cultural.
                </p>
            </div>
            <div class="pag2__sectionA__divImg pag2__sections__50">
                <img src="img/pag2/origen.jpg" class="pag2__section__Img">
            </div>
        </section>


        <!--SECTION 2-->
        <section class="pag2__sectionB">
            <div class="pag2__section__divText pag2__sections__50">
                <h2 class="pag2__section__h2">Evolucion</h2>
                <p class="pag2__section__p">
                    De acuerdo a los naipes del siglo XV descubiertos en el Palacio Topkapi, la baraja española proviene de la baraja otomana: cuatro palos, tres figuras, diez números. <br>
                    En su viaje hacia las manos del pueblo español, su iconografía se adaptó a las costumbres de la Europa Occidental. Así, el “taco de polo” devino en “basto”, aparecieron figuras como la sota (representación del paje, ese joven hidalgo al servicio del noble) y la espada dejó su forma curva de alfanje en favor de una recta. <br>
                    Todo parece indicar que el truco, de la misma manera, tiene origen árabe. <br>
                    La etimología proviene de la palabra “truk” o “truch”, y designa todos los ardides necesarios para su juego. Una leyenda cifra el origen de sus reglas en un pequeño robo. Decididos a jugar a la guerra, unos niños moros tomaron la baraja de sus mayores y quitaron reyes, caballos y sotas para recortarlos y usarlos como figuras andantes. El as de oros quedó cifrado como símbolo y el de copas fue el premio. <br>
                    Molestos ante la imposibilidad de jugar una partida de brisca, los mayores tomaron ese mazo diezmado y desarrollaron las primeras reglas del truk.

                    Conocido como “joc de truc” en Valencia, el juego viajó a Sudamérica con las oleadas de migrantes. Así, de la misma manera en que se juega en Baleares o Cuenca, se extendió en pulperías y asentamientos coloniales de Argentina, el Uruguay, sur de Chile y el estado brasileño de Rio Grande do Sul. En Murcia, por ejemplo, tiene sus propios valores y se conoce como “truque”. Y también en Galicia, donde, se sospecha, desembarcó con aquellos migrantes de regreso. <br>
                </p>
            </div>
            <div class="pag2__section__divImg pag2__sections__50">
                <img src="img/pag2/palacio.jpg" class="pag2__section__Img">
            </div>
        </section>

        <!--SECTION 3-->
        <section class="pag2__sectionC">
           <div class="pag2__sectionC__content">

            <div class="pag2__sectionC__divRedondo">
                <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-cat" width="76" height="76" viewBox="0 0 24 24" stroke-width="1.5" stroke="#559656" fill="none" stroke-linecap="round" stroke-linejoin="round">
                    <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                    <path d="M20 3v10a8 8 0 1 1 -16 0v-10l3.432 3.432a7.963 7.963 0 0 1 4.568 -1.432c1.769 0 3.403 .574 4.728 1.546l3.272 -3.546z" />
                    <path d="M2 16h5l-4 4" />
                    <path d="M22 16h-5l4 4" />
                    <path d="M12 16m-1 0a1 1 0 1 0 2 0a1 1 0 1 0 -2 0" />
                    <path d="M9 11v.01" />
                    <path d="M15 11v.01" />
                </svg>
                <h3 class="pag2__sectionC__h3">Influencia Cultural</h3>
                <p class="pag2__sectionC__p">
                    Además de ser un juego de cartas, el Truco ha influido en la cultura popular de Argentina y Uruguay.
                    Se ha mencionado en canciones, películas y literatura, y ha contribuido a la construcción de identidad y
                    tradiciones en estas regiones.
                </p>
            </div>

            <div class="pag2__sectionC__divRedondo">
                <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-devices-pc" width="76" height="76" viewBox="0 0 24 24" stroke-width="1.5" stroke="#559656" fill="none" stroke-linecap="round" stroke-linejoin="round">
                    <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                    <path d="M3 5h6v14h-6z" />
                    <path d="M12 9h10v7h-10z" />
                    <path d="M14 19h6" />
                    <path d="M17 16v3" />
                    <path d="M6 13v.01" />
                    <path d="M6 16v.01" />
                </svg>
                <h3 class="pag2__sectionC__h3">Adaptacion Online</h3>
                <p class="pag2__sectionC__p">
                    Con la llegada de la tecnología y los juegos en línea, el Truco también encontró su camino en plataformas
                    digitales. Hay múltiples aplicaciones y sitios web que permiten a los jugadores disfrutar del juego en línea
                    con amigos y desconocidos de todo el mundo.
                </p>
            </div>

            <div class="pag2__sectionC__divRedondo">
                <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-ruler-2" width="76" height="76" viewBox="0 0 24 24" stroke-width="1.5" stroke="#559656" fill="none" stroke-linecap="round" stroke-linejoin="round">
                    <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                    <path d="M17 3l4 4l-14 14l-4 -4z" />
                    <path d="M16 7l-1.5 -1.5" />
                    <path d="M13 10l-1.5 -1.5" />
                    <path d="M10 13l-1.5 -1.5" />
                    <path d="M7 16l-1.5 -1.5" />
                  </svg>
                <h3 class="pag2__sectionC__h3">Evolucion de las reglas</h3>
                <p class="pag2__sectionC__p">
                    A lo largo del tiempo, las reglas del Truco han variado según la región y las preferencias
                    de los jugadores. Esto ha llevado a la aparición de distintas versiones del juego, como el Truco Paulista, el
                    Truco Mineiro, el Truco Carioca, entre otros, cada uno con sus propias reglas y características únicas.
                </p>
            </div>

           </div>
        </section>



    </main>

    <!--footer-->
    <footer class="pag__footer">
        <!--<hr class="pag2__footer__hr">-->

        <section class="pag__footer__content">
            <div class="pag__footer__divNombres">
                <p>Rodrigo Laviano</p>
                <p>Lautaro Rostan</p>
                <p>Nazareno Arcieri</p>
            </div>

            <div class="pag__footer__fivRedes">
                <a href="#">
                    <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-brand-facebook" width="44" height="44" viewBox="0 0 24 24" stroke-width="1.5" stroke="#2c3e50" fill="none" stroke-linecap="round" stroke-linejoin="round">
                    <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                    <path d="M7 10v4h3v7h4v-7h3l1 -4h-4v-2a1 1 0 0 1 1 -1h3v-4h-3a5 5 0 0 0 -5 5v2h-3" />
                    </svg>
                </a>
                <a href="#">
                    <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-brand-instagram" width="44" height="44" viewBox="0 0 24 24" stroke-width="1.5" stroke="#2c3e50" fill="none" stroke-linecap="round" stroke-linejoin="round">
                        <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                        <path d="M4 4m0 4a4 4 0 0 1 4 -4h8a4 4 0 0 1 4 4v8a4 4 0 0 1 -4 4h-8a4 4 0 0 1 -4 -4z" />
                        <path d="M12 12m-3 0a3 3 0 1 0 6 0a3 3 0 1 0 -6 0" />
                        <path d="M16.5 7.5l0 .01" />
                    </svg>
                </a>
                <a href="#">
                    <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-brand-twitter" width="44" height="44" viewBox="0 0 24 24" stroke-width="1.5" stroke="#2c3e50" fill="none" stroke-linecap="round" stroke-linejoin="round">
                        <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                        <path d="M22 4.01c-1 .49 -1.98 .689 -3 .99c-1.121 -1.265 -2.783 -1.335 -4.38 -.737s-2.643 2.06 -2.62 3.737v1c-3.245 .083 -6.135 -1.395 -8 -4c0 0 -4.182 7.433 4 11c-1.872 1.247 -3.739 2.088 -6 2c3.308 1.803 6.913 2.423 10.034 1.517c3.58 -1.04 6.522 -3.723 7.651 -7.742a13.84 13.84 0 0 0 .497 -3.753c0 -.249 1.51 -2.772 1.818 -4.013z" />
                    </svg>
                </a>
            </div>
        </section>
    </footer>
</body>
</html>
