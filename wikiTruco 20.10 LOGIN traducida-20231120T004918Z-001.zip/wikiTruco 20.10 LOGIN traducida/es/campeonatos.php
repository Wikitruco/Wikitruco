<?php
session_start();
$logo = '<svg xmlns="http://www.w3.org/2000/svg" width="30" height="18" fill="currentColor" class="bi bi-person-circle" viewBox="0 0 16 16">
<path d="M11 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0z"/>
<path fill-rule="evenodd" d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8zm8-7a7 7 0 0 0-5.468 11.37C3.242 11.226 4.805 10 8 10s4.757 1.225 5.468 2.37A7 7 0 0 0 8 1z"/>
</svg>'

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Campeonatos</title>
    <link rel="shortcut icon" href="img/pag1/icono.jpg">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Staatliches&family=Work+Sans:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="./css/normalize.css">
    <link rel="stylesheet" href="./css/style.css">

</head>
<body>

     <!--NAV-->
     <nav class="pag__nav">
        <div class="pag__nav__div__img"> <a class="pag__nav__imgLink" href="index.php"><img class="pag__nav__img" src="img/pag1/logo.png"></a></div>
        <div class="pag__nav__div__a">
            <a href="index.php" class="pag__nav__a">Inicio</a>
            <a href="historia.php" class="pag__nav__a">Historia</a>
            <a href="uruguayo.php" class="pag__nav__a">Uruguayo</a>
            <a href="argentino.php" class="pag__nav__a">Argentino</a>
            <a href="../en/encampeonatos.php" class="pag1__a">EN</a>
            <?php
                if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true) {

                    echo '<a href="./Login/user.php" class="pag__nav__a">' . $_SESSION["username"] . $logo .'</a>';

                }else{
                    echo '<a href="./Login/user.php" class="pag__nav__a">Cuenta</a>';
                }
            ?>
        </div>
    </nav>

    <header>
        <img src="img/pag5/gentetruquito.jpg" class="pag2__header__img" width="900px" height="700px">
    </header>

    <main class="pag5_main">

        <div class="grid-container">
            <div class="grid-item">
                <h3>Categorías:</h3>
                <p>Los campeonatos de truco suelen tener diferentes categorías o divisiones, dependiendo del nivel de habilidad de los jugadores. Pueden haber competiciones para jugadores principiantes, intermedios y avanzados.</p>
            </div>
            <div class="grid-item">
                <h3>Organización: </h3>
                <p>Estos campeonatos pueden ser organizados por clubes, asociaciones de truco o instituciones deportivas. A menudo, hay torneos locales, regionales y nacionales, y los ganadores de las competencias locales pueden clasificarse para competencias de nivel superior.</p>
            </div>
            <div class="grid-item">
                <h3>Premios: </h3>
                <p>Los campeonatos de truco a menudo ofrecen premios en efectivo, trofeos, medallas u otros incentivos para los ganadores y finalistas. Los premios pueden variar según la magnitud del torneo.</p>
            </div>
            <div class="grid-item">
                <h3>Difusión: </h3>
                <p>Algunos campeonatos de truco son televisados o transmitidos en línea, lo que les da una mayor visibilidad. Esto ha contribuido a que el truco sea un juego aún más popular en algunas regiones.</p>
            </div>
            <div class="grid-item">
                <h3>Comunidad y cultura: </h3>
                <p>El truco no es solo un juego, sino también una parte importante de la cultura en algunos países. Los jugadores suelen formar comunidades y clubs dedicados al truco, y los campeonatos son ocasiones para socializar y demostrar habilidades.</p>
            </div>
            <div class="grid-item">
                <h3>Estrategia y habilidades: </h3>
                <p>Para tener éxito en un campeonato de truco, se requiere una combinación de habilidades cardíacas, estrategia, memoria y capacidad para leer las señas del oponente. Los jugadores experimentados pueden anticipar los movimientos de sus oponentes y utilizar señas para comunicarse con su compañero de equipo de manera efectiva.</p>
            </div>
        </div>



        <section class="pag5__sectionB">
            <div class="pag5__sectionB__divImg">
                <img class="pag5__sectionB__divImg__img" src="img/pag5/invitetotruco.png" >
            </div>
            <div class="pag5__sectionB__divText">
                <h1 >Torneo de Truco Uruguayo</h1>
                <h2 class="h1">Fecha: <b>16/11</b></h2>
                <h2 class="h1">Informacion del Torneo</h2>
                <h3 class="premios">Premios</h3>
                <p class="premios">
                    <b>1ero</b> Asado para 2 personas y un whisky Red Label<br>
                    <b>2do</b> 2 Billeteras Polo con 500 pesos<br>
                    <b>3ero</b> 800 pesos<br>
                    <br>
                    Con solo pagar la inscripcion participas en un torneo de una moto city 125 0km
                </p>
                <h2 class="h1">Reglas</h2>
                <p>
                    <h4>Artículo 1º - AUTORIDADES: </h4> El torneo tendrá un jurado a cargo del Señor Presidente de la Institución, quien designará a dos (2) socios para integrar una comisión que además de fiscalizar las mesas de juego nombrando para ello a un socio –libre de juego- en calidad de veedor, determinará la realización de las distintas rondas, acreditará los puntajes y a la postre será la encargada de determinar las posiciones para la obtención de los premios previstos y que se anunciarán debidamente antes de la iniciación del evento.<br>

                    <h4>Artículo 2º - CONTROVERSIAS: </h4> Ante cualquier tipo de controversias que pudiera suscitarse entre los contrincantes, deberán someterse a la decisión del veedor designado, y para que, llegado el caso no quedaren conformes se admitirá el recurso respectivo que será dilucidado en forma inmediata por la Comisión designada de conformidad al artículo anterior, siendo su decisión irrevocable y de última instancia, debiendo los jugadores acatar la misma, y de no ser así, con la posibilidad de ser separado del torneo, circunstancias éstas que se recordarán antes de la iniciación de las partidas, recordándoles a los partícipes que no se permitirá bajo ningún concepto que se perturbe el clima de camaradería, respeto y amistad que impera de por siempre en el Timón Club.<br>

                    <h4>Artículo 3º - CANTIDAD DE JUGADORES: </h4> Cada equipo estará integrado por tres (3) personas, sin importar el sexo, las que se sentarán intercaladamente, siendo la mano a la derecha para repartir cartas, pasando de una vez por cada participante.<br>

                    <h4>Artículo 4º - FORMA DE INICIO: </h4> Para establecer quien va a ser el primero en dar cartas, cada uno tomará del mazo un naipe, siendo el que obtenga el mayor puntaje el que comenzará el juego, continuándose la mano en la forma mencionada en el artículo anterior.- En caso de empate, solamente entre los partícipes se repetirá la operación hasta que resulte sólo uno con un puntaje mayor.<br>

                    <h4>Artículo 5º - FORMA DE JUEGO: </h4> Se jugarán partidos consistentes en la obtención de Quince (15) primeros puntos llamados “MALAS” y Quince (15) siguientes puntos llamados “BUENOS”, y completados estos últimos, quien los logre primero será el ganador.- Hasta la obtención de los Cinco (5) primeros puntos (Malos) jugarán entre todos según se denomina “REDONDO” y luego de que uno de los equipos obtenga Diez (10) puntos de la segunda etapa (Buenos) también hasta completar la partida y resultar uno ganador.- Luego de los primeros Cinco (5) puntos Malos, mencionados y hasta llegar a los otros Diez (10) puntos Buenos, se jugarán intercaladamente partidas entre todos (redondas) o en forma individual, los que se encuentren enfrentados de distintos equipos, denominadas ésta “Pica a Pica”, y en las que la “Falta Envido” tendrá un valor único, de ser querida, para el ganador de Seis (6) puntos únicamente.<br>

                    <h4>Artículo 6º - PUNTAJES: </h4> No se jugará con “FLOR”, y para el caso de que un jugador obtenga las tres (3) cartas del mismo palo, para el “Punto” deberá cantar exclusivamente el mayor puntaje que sume con dos (2) cartas, no pudiendo cantar un punto menor, aunque de quedar de “pié” ganara cantando el punto menor.- De determinarse que ello ocurrió, perderá el puntaje que hubiera obtenido, siendo anotado para el equipo contrincante.<br>
                </p>
            </div>

        </section>
    </main>

     <!--footer-->
     <footer class="pag__footer">
        <!--<hr class="pag2__footer__hr">-->

        <section class="pag__footer__content">
            <div class="pag__footer__divNombres">
                <p>Rodrigo Laviano</p>
                <p>Lautaro Rostan</p>
                <p>Nazareno Arcieri</p>
            </div>

            <div class="pag__footer__fivRedes">
                <a href="#">
                    <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-brand-facebook" width="44" height="44" viewBox="0 0 24 24" stroke-width="1.5" stroke="#2c3e50" fill="none" stroke-linecap="round" stroke-linejoin="round">
                    <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                    <path d="M7 10v4h3v7h4v-7h3l1 -4h-4v-2a1 1 0 0 1 1 -1h3v-4h-3a5 5 0 0 0 -5 5v2h-3" />
                    </svg>
                </a>
                <a href="#">
                    <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-brand-instagram" width="44" height="44" viewBox="0 0 24 24" stroke-width="1.5" stroke="#2c3e50" fill="none" stroke-linecap="round" stroke-linejoin="round">
                        <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                        <path d="M4 4m0 4a4 4 0 0 1 4 -4h8a4 4 0 0 1 4 4v8a4 4 0 0 1 -4 4h-8a4 4 0 0 1 -4 -4z" />
                        <path d="M12 12m-3 0a3 3 0 1 0 6 0a3 3 0 1 0 -6 0" />
                        <path d="M16.5 7.5l0 .01" />
                    </svg>
                </a>
                <a href="#">
                    <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-brand-twitter" width="44" height="44" viewBox="0 0 24 24" stroke-width="1.5" stroke="#2c3e50" fill="none" stroke-linecap="round" stroke-linejoin="round">
                        <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                        <path d="M22 4.01c-1 .49 -1.98 .689 -3 .99c-1.121 -1.265 -2.783 -1.335 -4.38 -.737s-2.643 2.06 -2.62 3.737v1c-3.245 .083 -6.135 -1.395 -8 -4c0 0 -4.182 7.433 4 11c-1.872 1.247 -3.739 2.088 -6 2c3.308 1.803 6.913 2.423 10.034 1.517c3.58 -1.04 6.522 -3.723 7.651 -7.742a13.84 13.84 0 0 0 .497 -3.753c0 -.249 1.51 -2.772 1.818 -4.013z" />
                    </svg>
                </a>
            </div>
        </section>
    </footer>


</body>
</html>
